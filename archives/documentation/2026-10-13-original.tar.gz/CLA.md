# 十组邮件小助手 Contributors License Agreement

This Contributors License Agreement ("CLA") is entered into between the Contributor, and 十组邮件小助手, collectively referred to as the "Parties."

## Background:

十组邮件小助手 is an open-source project aimed at providing an open-source app to help manage email better. This CLA governs the rights and contributions made by the Contributor to the 十组邮件小助手 project.

## Agreement:

**Contributor Grant of License:**

By submitting code, documentation, or any other materials (collectively, "Contributions") to the 十组邮件小助手 project, the Contributor grants 十组邮件小助手 a perpetual, worldwide, non-exclusive, royalty-free, sublicensable license to use, modify, distribute, and otherwise exploit the Contributions, including any intellectual property rights therein, for the purposes of the 十组邮件小助手 project.

**Representation of Ownership and Right to Contribute:**

The Contributor represents that they have the legal right to grant the license stated in Section 1, and that the Contributions do not infringe upon the intellectual property rights of any third party. The Contributor also represents that they have the authority to submit the Contributions on their own behalf or, if applicable, on behalf of their employer or any other entity.

**Patent Grant:**

If the Contributions include any method, process, or apparatus that is covered by a patent, the Contributor agrees to grant 十组邮件小助手 a non-exclusive, worldwide, royalty-free license under any patent claims necessary to use, modify, distribute, and otherwise exploit the Contributions for the purposes of the 十组邮件小助手 project.

**No Implied Warranties or Support:**

The Contributor acknowledges that the Contributions are provided "as is," without any warranties or support of any kind. 十组邮件小助手 shall have no obligation to provide maintenance, updates, bug fixes, or support for the Contributions.

**Retention of Contributor Rights:**

The Contributor retains all right, title, and interest in and to their Contributions. This CLA does not restrict the Contributor from using their own Contributions for any other purpose.

**Governing Law:**

This CLA shall be governed by and construed in accordance with the laws of Israel, without regard to its conflict of laws principles.

**Entire Agreement:**

This CLA constitutes the entire agreement between the Parties with respect to the subject matter hereof and supersedes all prior and contemporaneous understandings, agreements, representations, and warranties.

**Acceptance:**

By submitting Contributions to the 十组邮件小助手 project, the Contributor acknowledges and agrees to the terms and conditions of this CLA. If the Contributor is agreeing to this CLA on behalf of an entity, they represent that they have the necessary authority to bind that entity to these terms.

**Effective Date:**

This CLA is effective as of the date of the first Contribution made by the Contributor to the 十组邮件小助手 project.
