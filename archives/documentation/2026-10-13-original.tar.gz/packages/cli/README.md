# @inbox-zero/cli

CLI tool for running [十组邮件小助手](https://www.getinboxzero.com) - an open-source AI email assistant.

## Installation

### Homebrew (macOS/Linux)

```bash
brew install inbox-zero/inbox-zero/inbox-zero
```

### Manual Installation

Download the binary for your platform from [releases](https://github.com/elie222/inbox-zero/releases) and add to your PATH.

## Quick Start

```bash
# Configure 十组邮件小助手 (interactive)
inbox-zero setup

# Start 十组邮件小助手
inbox-zero start

# Open http://localhost:3000
```

## Commands

### `inbox-zero setup`

Interactive setup wizard that:
- Configures OAuth providers (Google/Microsoft)
- Sets up your LLM provider and API key
- Configures ports (to avoid conflicts)
- Generates all required secrets

Configuration is stored in `~/.inbox-zero/`

### `inbox-zero setup-terraform`

Generates Terraform files for AWS deployment (ECS Fargate, RDS, optional Redis).

```bash
# Generate Terraform files in ./terraform (interactive)
inbox-zero setup-terraform

# Non-interactive mode (values read from flags/env vars)
inbox-zero setup-terraform --yes --region us-east-1
```

The generated Terraform uses AWS SSM Parameter Store for secrets and outputs the
service URL after `terraform apply`.

### `inbox-zero setup-vercel`

Links a Vercel project for `apps/web`, provisions Neon and Upstash Redis using
Vercel Marketplace integrations, and seeds the required environment variables.

```bash
# Interactive Vercel setup
inbox-zero setup-vercel

# Skip provisioning an integration you already have
inbox-zero setup-vercel --skip-neon

# Non-interactive setup with defaults and placeholder provider credentials
inbox-zero setup-vercel --yes
```

Use `--deploy` if you want the CLI to trigger `vercel deploy --prod` after setup.

### `inbox-zero start`

Pulls the latest Docker image and starts all containers:
- PostgreSQL database
- Redis cache
- 十组邮件小助手 web app
- Cron job for email sync

```bash
inbox-zero start           # Start in background
inbox-zero start --no-detach  # Start in foreground
```

### `inbox-zero stop`

Stops all running containers.

```bash
inbox-zero stop
```

### `inbox-zero logs`

View container logs.

```bash
inbox-zero logs            # Show last 100 lines
inbox-zero logs -f         # Follow logs
inbox-zero logs -n 500     # Show last 500 lines
```

### `inbox-zero status`

Show status of running containers.

### `inbox-zero update`

Pull the latest 十组邮件小助手 image and optionally restart.

```bash
inbox-zero update
```

## Requirements

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running
- OAuth credentials from Google and/or Microsoft
- An LLM API key (Anthropic, OpenAI, Google, etc.)

## Configuration

All configuration is stored in `~/.inbox-zero/`:
- `.env` - Environment variables
- `docker-compose.yml` - Docker Compose configuration

To reconfigure, run `inbox-zero setup` again.

## License

See [LICENSE](../../LICENSE) in the repository root.
